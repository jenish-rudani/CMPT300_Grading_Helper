
#include "s_talk.h"



int main(int argc, char **argv)
{
    s_talk(argc, argv);

    return 0;
}