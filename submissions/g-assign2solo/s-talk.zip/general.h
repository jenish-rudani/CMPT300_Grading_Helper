#ifndef _GENERAL_H_
#define _GENERAL_H_

#define MSG_MAX_LEN 256

void sleep_usec(long usec);
void sleep_msec(long msec);

#endif