Issues/Unfinished Parts of this assignment that I was unable to resolve:

    1) This only works with two terminals on the localhost. I was unable to get it to connect to two different computers.
        This probably won't run if testing like the example in the document written on the document. It might be becaause I'm using a deprecated function to resolve the machine name but I'm not fully sure. This was my fault for not testing with two different machine names in the first place.
        ./stalk 8000 localhost 8001 and ./stalk 8001 localhost 8000 should work though.

    2) When using "!" to end, it only ends one end of the chat
