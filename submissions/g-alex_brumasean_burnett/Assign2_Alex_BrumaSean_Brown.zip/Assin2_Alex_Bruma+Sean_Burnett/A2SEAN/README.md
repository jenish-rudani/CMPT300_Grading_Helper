By Alex Bruma and Sean Burnett

Program execution: 
    open 2 termninals.

    run the code (./client) on each terminal

    type "s-talk 30000 csil-cpu3 22110" on one terminal and "s-talk 22110 csil-cpu1 30000" on the other 
    (any valid port #s will work)

    To quit simply type a "!" on one terminal followed by enter 
    (this ends 7/8 of the threads, to end the last one you must press enter on the other terminal)

Note:
    This program does not work across different computers (including csil)
