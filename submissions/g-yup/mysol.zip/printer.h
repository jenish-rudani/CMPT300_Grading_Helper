#ifndef _PRINTER_H_
#define _PRINTER_H_

void Printer_init();
void Printer_signal();
void Printer_cancel();
void Printer_waitForShutdown();

#endif