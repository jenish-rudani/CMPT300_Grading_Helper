#ifndef _SCREEN_H_
#define _SCREEN_H_

//startup screen module
void Screen_init();
//shutdown screen module
void Screen_shutDown();


#endif 