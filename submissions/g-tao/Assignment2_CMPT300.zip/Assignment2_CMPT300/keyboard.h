#ifndef _KEYBOARD_H_
#define _KEYBOARD_H_

//startup keyboard module
void Keyboard_init();
//shutdown keyboard module
void Keyboard_shutDown();


#endif 