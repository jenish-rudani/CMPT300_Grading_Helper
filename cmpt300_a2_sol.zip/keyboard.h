#ifndef _KEYBOARD_H_
#define _KEYBOARD_H_

void Keyboard_init();
void Keyboard_shutdown();

#endif