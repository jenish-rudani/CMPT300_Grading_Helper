#ifndef _SCREEN_H_
#define _SCREEN_H_

void Screen_init();
void Screen_shutdown();

void Screen_printMessage(char *message);

#endif