#ifndef RECEIVE_H_
#define RECEIVE_H_

void Receive_init();
void Receive_shutdown();

#endif