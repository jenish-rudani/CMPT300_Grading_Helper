#ifndef _SEND_H_

void Send_init();
void Send_shutdown();

void Send_sendMessage(char *pMessage);

#endif 